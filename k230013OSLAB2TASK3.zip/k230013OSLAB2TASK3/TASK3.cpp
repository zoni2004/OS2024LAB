#include <iostream>
#include <vector>
#include <algorithm>
#include <stdlib.h>
using namespace std;

int main(int argc, char* argv[]){
          if(argc < 2){
               cerr<< "Usage: "<< argv[0] <<" <list of integers>" <<"\n";
               return 1;
          }
          
         vector<int> numbers;
         
        for (int i=1; i<argc; i++){
            numbers.push_back(atoi(argv[i]));
        }

        sort(numbers.begin(), numbers.end());

        cout<<"Sorted Numbers: ";
        for(int num : numbers){
            cout<< num<< " ";
        }
        cout<<"\n";

       return 0;
}
